# Food-O-Clock
A Demo Food Ordering Web application made using React and deployed on Firebase. 
The user can add the desired dishes to the cart and then order after filling a basic form.
